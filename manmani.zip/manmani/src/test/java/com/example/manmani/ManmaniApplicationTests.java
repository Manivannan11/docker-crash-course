package com.example.manmani;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManmaniApplicationTests {

	@Test
	void contextLoads() {
	}

}
