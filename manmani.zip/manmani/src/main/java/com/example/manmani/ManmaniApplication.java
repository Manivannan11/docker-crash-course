package com.example.manmani;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManmaniApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManmaniApplication.class, args);
	}

}
